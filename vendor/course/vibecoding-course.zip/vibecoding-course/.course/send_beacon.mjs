#!/usr/bin/env node
// Отправка маяка завершения трека в академию — с подписью.
//
// Зачем отдельный файл, а не строка curl в скилле: тело нужно ПОДПИСАТЬ, а
// подпись — это HMAC-SHA256 с меткой времени. Просить агента собрать её вручную
// в консоли значит каждый раз заново спорить с экранированием кавычек, кириллицей
// в PowerShell и форматом времени. Здесь это делается один раз и одинаково на
// Windows и macOS.
//
// Запуск (из корня курса):
//     node .course/send_beacon.mjs <файл-с-телом.json>
//
// В файле — только содержательные поля, БЕЗ ts и sig (их ставит этот скрипт):
//     {"course":"Вайбкодинг с Claude Code","role":"Маркетолог",
//      "missions_passed":7,"completed_at":"2026-08-20T10:00:00+03:00",
//      "email":"student@example.com"}
//
// Настройки берутся из .course/config.yaml, блок completion_beacon:
//     enabled: true
//     url: "https://academy.hamidun.com/api/course-completion"
//     secret: "..."      # вписывает установщик; пусто = шлём без подписи
//
// Коды выхода: 0 — сервер принял (2xx), 1 — не принял или не смогли отправить,
// 2 — маяк выключен/не настроен (это НЕ ошибка курса, просто нечего делать).

import { createHmac } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { request as httpsRequest } from 'node:https';
import { request as httpRequest } from 'node:http';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const COURSE_DIR = dirname(fileURLToPath(import.meta.url));   // .course/
const CONFIG = resolve(COURSE_DIR, 'config.yaml');

// Минимальный разбор ровно одного блока config.yaml. Полноценный YAML-парсер сюда
// тащить незачем: блок пишет установщик по фиксированному шаблону, а ошибиться
// на чужих ключах мы не можем — читаем только внутри completion_beacon.
function readBeaconConfig(path) {
  let text;
  try {
    text = readFileSync(path, 'utf8');
  } catch {
    return { enabled: false, url: '', secret: '' };
  }
  const out = { enabled: false, url: '', secret: '' };
  let inside = false;
  for (const rawLine of text.split(/\r?\n/)) {
    if (/^completion_beacon:\s*$/.test(rawLine)) { inside = true; continue; }
    if (inside && /^\S/.test(rawLine)) break;          // начался следующий блок
    if (!inside) continue;
    const m = rawLine.match(/^\s+(enabled|url|secret):\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if (v.startsWith('"')) {
      // Установщик пишет значения как YAML-строку в двойных кавычках, экранируя
      // \ и ". Хвостовой комментарий у таких строк режем ПОСЛЕ закрывающей
      // кавычки — иначе секрет с решёткой обрезался бы посередине.
      const q = v.match(/^"((?:\\.|[^"\\])*)"/);
      v = q ? q[1].replace(/\\(["\\])/g, '$1') : v.slice(1);
    } else if (v.startsWith("'")) {
      const q = v.match(/^'((?:[^']|'')*)'/);
      v = q ? q[1].replace(/''/g, "'") : v.slice(1);
    } else {
      v = v.replace(/\s+#.*$/, '').trim();             // enabled: false  # ...
    }
    if (m[1] === 'enabled') out.enabled = /^(true|yes|1)$/i.test(v);
    else out[m[1]] = v;
  }
  return out;
}

function fail(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

const bodyPath = process.argv[2];
if (!bodyPath) fail('Укажи файл с телом: node .course/send_beacon.mjs body.json');

const cfg = readBeaconConfig(CONFIG);
if (!cfg.enabled || !cfg.url) {
  console.log('Маяк выключен или адрес не задан — отправлять нечего.');
  process.exit(2);
}

let payload;
try {
  payload = JSON.parse(readFileSync(bodyPath, 'utf8'));
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new Error('в файле не JSON-объект');
  }
} catch (e) {
  fail(`Не смог прочитать тело из ${bodyPath}: ${e.message}`);
}
if (!payload.course) fail('В теле нет поля course — сервер такой маяк не примет.');

// ts и sig ставим ТОЛЬКО здесь: если они приехали в файле, это чужие данные.
delete payload.ts;
delete payload.sig;

// Подписываем ровно то, что сервер потом соберёт заново: время, e-mail
// (пустая строка у анонимного маяка) и название курса. Метка времени внутри
// подписи — чтобы подсмотренный запрос нельзя было переиграть завтра.
const ts = String(Math.floor(Date.now() / 1000));
const email = String(payload.email || '').trim().toLowerCase();
if (email) payload.email = email;

payload.ts = ts;
if (cfg.secret) {
  payload.sig = createHmac('sha256', cfg.secret)
    .update(`${ts}|${email}|${payload.course}`, 'utf8')
    .digest('hex');
} else {
  // Секрет не прописан (сборка до раскатки подписи). Пока академия работает в
  // мягком режиме, такой маяк примут — но пометят «без подписи».
  console.error('ВНИМАНИЕ: секрет маяка не задан — отправляю без подписи.');
}

const data = Buffer.from(JSON.stringify(payload), 'utf8');
let target;
try {
  target = new URL(cfg.url);
} catch {
  fail(`Адрес маяка не разбирается как URL: ${cfg.url}`);
}
const doRequest = target.protocol === 'http:' ? httpRequest : httpsRequest;

const req = doRequest(target, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length,
  },
  timeout: 10000,
}, (res) => {
  const chunks = [];
  res.on('data', (c) => chunks.push(c));
  res.on('end', () => {
    const text = Buffer.concat(chunks).toString('utf8').slice(0, 500);
    const ok = res.statusCode >= 200 && res.statusCode < 300;
    console.log(`HTTP ${res.statusCode} ${text}`);
    // Ровно этот код читает скилл: 0 — можно записывать трек в beacon_sent.
    process.exit(ok ? 0 : 1);
  });
});
req.on('timeout', () => { req.destroy(new Error('таймаут 10с')); });
req.on('error', (e) => fail(`Маяк не ушёл (не критично, курс работает офлайн): ${e.message}`));
req.write(data);
req.end();
